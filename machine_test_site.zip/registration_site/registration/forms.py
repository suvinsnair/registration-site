from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.core.exceptions import ValidationError, ObjectDoesNotExist
from .models import UserProfile
from . import constants

# Create your forms here.

class NewUserForm(UserCreationForm):
	email = forms.EmailField(required=True)
	role = forms.ChoiceField(choices=constants.role_choices)
	country = forms.CharField(max_length=12)
	nationality = forms.CharField(max_length=12)
	mobile_num = forms.CharField(label="Mobile Number", max_length=10)

	class Meta:
		model = User
		fields = ("first_name", "last_name", "email", "role", "country",
		"nationality", "mobile_num", "password1", "password2")

	def save(self, commit=True):
		user = super(NewUserForm, self).save(commit=False)
		user.email = self.cleaned_data['email']
		if commit:
			user.save()
		return user

class UserLoginForm(forms.Form):
	email = forms.CharField(max_length=50)
	password = forms.CharField(widget=forms.PasswordInput())

	def __init__(self, *args, **kwargs):
		super(UserLoginForm, self).__init__(*args, **kwargs)
		for field in self.fields:
			self.fields[field].widget.attrs['class'] = 'form-control'

	def clean(self):
		email = self.cleaned_data.get("email")
		try:
			user = User.objects.get(email=email,is_active=True)
			self.cleaned_data['username'] = user.username
		except ObjectDoesNotExist:
			raise ValidationError('Invalid Email Address')
		return self.cleaned_data

	# def confirm_login_allowed(self, user):
	# 	if not user.is_active:
	# 		raise ValidationError("This account is inactive.")

	# def get_invalid_login_error(self):
	# 	return ValidationError(
    #         "Please enter a correct %(username)s and password. Note that both "
    #         "fields may be case-sensitive.",
    #         params={"username": self.username_field.verbose_name},
	# 	)
