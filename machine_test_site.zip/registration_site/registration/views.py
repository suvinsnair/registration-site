from django.shortcuts import  render, redirect
from registration.forms import NewUserForm, UserLoginForm
from django.contrib.auth import login, authenticate, logout
from django.contrib import messages
from django.views import generic
from django.utils import decorators
from django.views.decorators.csrf import csrf_exempt
from .models import UserProfile, LoginDetails
from django.contrib.auth.forms import AuthenticationForm

def register_request(request):
    if request.method == "POST":
        form = NewUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            user_profile = UserProfile(user=user,role=int(form.cleaned_data["role"]),
			country=form.cleaned_data["country"],nationality=form.cleaned_data["nationality"],
			contact=form.cleaned_data["mobile_num"])
            user_profile.save()
            login(request, user)
            messages.success(request, "Registration successful." )
            return redirect("homepage")
        messages.error(request, "Unsuccessful registration. Invalid information.")
        return render(request=request, template_name="register.html", context={"register_form":form})
    else:
        form = NewUserForm()
        return render(request=request, template_name="register.html", context={"register_form":form})

class AdminDashboard(generic.TemplateView):
    template_name = 'index.html'

    def get(self, request, *args, **kwargs):
        context = super(AdminDashboard, self).get_context_data(**kwargs)
        context["login_details"] = LoginDetails.objects.filter(user=request.user).order_by('-created_at')[:10]
        context["user_details"] = UserProfile.objects.exclude(user=request.user).order_by('user')
        return self.render_to_response(context)

def login_request(request):
	
	if request.method == "POST":
		form = UserLoginForm(request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				LoginDetails.objects.create(user=user)
				messages.info(request, f"You are now logged in as {username}.")
				return redirect("homepage")
			else:
				messages.error(request,"Invalid username or password.")
		else:
			messages.error(request,"Invalid username or password.")
	form = UserLoginForm()
	return render(request=request, template_name="login.html", context={"login_form":form})

def logout_request(request):
	logout(request)
	messages.info(request, "You have successfully logged out.") 
	return redirect("login")
