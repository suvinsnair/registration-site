role_choices = (
    (0, "STUDENT"),
    (1, "STAFF"),
    (2, "ADMIN"),
    (3, "EDITOR"),
)